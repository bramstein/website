#ifndef INCLUDES_H
#define INCLUDES_H

#include "SDL.h"
#include "SDL_opengl.h"
#include <memory>
#include <exception>
#include <string>
#include <vector>
#include <algorithm>

#endif