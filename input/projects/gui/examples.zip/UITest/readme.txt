--------------------------------------------------------------
 UITest v0.03 - Bram Stein, 2003-2005
--------------------------------------------------------------
UITest is the demo executable for a yet unnamed gui library.
It demonstrates the basic features and serves as a test-bed
for these features. So if it crashes, formats your harddrive,
or sleeps with your girlfriend, it is not my fault. 

--------------------------------------------------------------
 Library features:
--------------------------------------------------------------
- written in C++ (standard, platform independant)
- fully rendered in OpenGL
- ability to modify and create custom themes
- can be used as an in-game texture (see demo)
- API similar to Java Swing API (similar, not a direct copy)
- does not depend on other libraries
- BSD license on source code

--------------------------------------------------------------
 Keyboard shortcuts:
--------------------------------------------------------------
<esc> - quit demo
<tab> - focus next component
<shift-tab> - focus previous component

--------------------------------------------------------------
 License
--------------------------------------------------------------
Note that the included font (Vera.ttf) falls under the license 
in "font_license.txt".