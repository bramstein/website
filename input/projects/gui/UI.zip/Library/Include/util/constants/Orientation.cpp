#include "./Orientation.h"

namespace ui
{
	namespace util
	{
		namespace constants
		{
			//const Orientation::HORIZONTAL(1);
			//const Orientation::VERTICAL(2);
		}
	}
}