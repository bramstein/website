*Highres Quake Menu Textures v0.01 - by Bram Stein*
These are highres Quake1 menu textures for use with modern Quake1 
engines such as Darkplaces. The design goal for these textures was 
to make them as close to the original textures as possible, but with 
a higher resolution. The textures are made at 1024x768 resolution 
and mostly use vector graphics and blend modes so that they can be 
easily resized without (major) quality loss. 

The textures come in two different formats, the original PSD 
(Photoshop) files and 24bit PNG files.

*Missing textures*
The following two parts are missing from the texture pack:
-The Id Software logo, for copyright reasons.
-The rotating Q, because I do not have a 3D program.

*Contact information*
I can be contacted by sending mail to bram AT quakesrc.org, or
at http://www.quakesrc.org/.

*License*
The art (PNG) and source files (PSD) are licensed under the 
GNU GPL license;

Highres Quake Menu Textures

Copyright (C) 2005  Bram Stein

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA